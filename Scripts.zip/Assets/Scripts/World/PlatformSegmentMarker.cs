using UnityEngine;

public class PlatformSegmentMarker : MonoBehaviour
{
    public float startX;
    public float endX;
    public float yCenter;   // for checking distance between segments
}
